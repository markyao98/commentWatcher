# coding:utf-8

from collections import Counter
from os import path
import jieba
import re
jieba.load_userdict(path.join(path.dirname(__file__), 'customDict/dict01.txt')) # 导入用户自定义词典

def word_segment(text):

    # 计算每个词出现的频率，并存入txt文件
    jieba_word=jieba.cut(text,cut_all=False) # cut_all是分词模式，True是全模式，False是精准模式，默认False
    data=[]
    ignore_words = ['我','的','有','和','是','很','了','咯','捂脸']
    for word in jieba_word:
        if len(word) >= 2 and re.match(r'^[\u4e00-\u9fa5a-zA-Z0-9]+$', word) and word not in ignore_words:  # 忽略长度小于1的词
            data.append(word)
    dataDict=Counter(data)
    top_words = dataDict.most_common(20)

    # 返回分词后的结果
    # jieba_word=jieba.cut(text,cut_all=False) # cut_all是分词模式，True是全模式，False是精准模式，默认False
    seg_list=' '.join(word for word in data if len(word) > 1)

    data = {
        'seg_list': seg_list,
        'top_words': top_words
    }
    return data

