# coding:utf-8

from os import path
import chnSegment
import plotWordcloud


if __name__=='__main__':

    # 读取文件
    d = path.dirname(__file__)
    text="2022年1月28日，国务院新闻办公室发布《2021中国的航天》白皮书，介绍2016年以来中国航天活动主要进展、未来五年主要任务，进一步增进国际社会对中国航天事业的了解。" \
         "白皮书约12500字，除前言、结束语外共包括六个部分，分别是开启全面建设航天强国新征程、发展空间技术与系统、培育壮大空间应用产业、开展空间科学探索与研究、推进航天治理现代化、构建航天国际合作新格局。"

    # 若是中文文本，则先进行分词操作
    text=chnSegment.word_segment(text)
    
    # 生成词云
    plotWordcloud.generate_wordcloud(text)
