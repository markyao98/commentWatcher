#coding=utf-8
from flask import Flask, json, Response
from flask import request
import chnSegment
import plotWordcloud
app = Flask(__name__)
@app.route('/analysisData', methods=['GET', 'POST'])
def analysis_data():
    data = request.get_json()
    text = data.get('text')
    data = chnSegment.word_segment(text.encode('utf-8').decode('utf-8'))
    text=data.get('seg_list')

    print(text)
    # 生成词云
    fileUrl=plotWordcloud.generate_wordcloud(text)
    # 创建响应对象
    response_data = {
        'wordCloudUrl': fileUrl,
        'top_words' : data.get('top_words')
    }

    response_json = json.dumps(response_data)

    return Response(response_json, content_type='application/json')


if __name__ == '__main__':
    app.run(host='localhost')

