CREATE TABLE `harvest_index_wal` IF NOT EXISTS (
     `id` bigint(20) NOT NULL AUTO_INCREMENT,
     `cid` bigint(20) NOT NULL COMMENT '主表id',
     `log_type` int(11) DEFAULT NULL COMMENT '日志类型:1插入,2删除',
     `event_status` int(11) DEFAULT NULL COMMENT '事件状态:0初始,1成功,2失败',
     `retry_cnt` int(11) DEFAULT NULL COMMENT '重试次数',
     `current_position` bigint(20) DEFAULT NULL COMMENT '当前指针位置',
     `binlog_filename` varchar(32) DEFAULT NULL COMMENT 'binlog文件名',
     `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
     `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更改时间:代表着失败或成功的时间',
     PRIMARY KEY (`id`)
)
